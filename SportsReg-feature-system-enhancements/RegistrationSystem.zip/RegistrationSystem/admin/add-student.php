<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
  $corepage = end($corepage);
  if ($corepage !== 'index.php') {
    if ($corepage == $corepage) {
      $corepage = explode('.', $corepage);
      header('Location: index.php?page=' . $corepage[0]);
    }
  }

  // Generate unique 6-digit Roll Number
  $roll = rand(100000, 999999);
  $check = mysqli_query($db_con, "SELECT `roll` FROM `student_info` WHERE `roll` = '$roll'");
  while (mysqli_num_rows($check) > 0) {
    $roll = rand(100000, 999999);
    $check = mysqli_query($db_con, "SELECT `roll` FROM `student_info` WHERE `roll` = '$roll'");
  }

  if (isset($_POST['addstudent'])) {
    $name = $_POST['name'];
    $roll = $_POST['roll']; // The readonly input still sends this value
    $address = $_POST['address'];
    $pcontact = $_POST['pcontact'];
    $sport = $_POST['sport'];

    $photo = explode('.', $_FILES['photo']['name']);
    $photo_ext = end($photo); 
    $photo_name = $roll . date('YmdHis') . '.' . $photo_ext;

    $query = "INSERT INTO `student_info`(`name`, `roll`, `class`, `city`, `pcontact`, `photo`) 
              VALUES ('$name', '$roll', '$sport', '$address', '$pcontact', '$photo_name');";

    if (mysqli_query($db_con, $query)) {
      $datainsert['insertsucess'] = '<p style="color: green;">Player Registered Successfully!</p>';
      move_uploaded_file($_FILES['photo']['tmp_name'], 'images/' . $photo_name);
    } else {
      $datainsert['inserterror'] = '<p style="color: red;">Registration Failed. Please check the information!</p>';
    }
  }
?>

<h1 class="text-primary"><i class="fas fa-user-plus"></i>  Register a Player <small class="text-warning">New Player Entry</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item" aria-current="page"><a href="index.php">Dashboard</a></li>
    <li class="breadcrumb-item active" aria-current="page">Add Player</li>
  </ol>
</nav>

<div class="row">
  <div class="col-sm-6">
    <?php if (isset($datainsert)) { ?>
      <div role="alert" aria-live="assertive" aria-atomic="true" class="toast fade" data-autohide="true" data-animation="true" data-delay="2000">
        <div class="toast-header">
          <strong class="mr-auto">Player Registration</strong>
          <small><?php echo date('d-M-Y'); ?></small>
          <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="toast-body">
          <?php 
            if (isset($datainsert['insertsucess'])) {
              echo $datainsert['insertsucess'];
            }
            if (isset($datainsert['inserterror'])) {
              echo $datainsert['inserterror'];
            }
          ?>
        </div>
      </div>
    <?php } ?>

    <form enctype="multipart/form-data" method="POST" action="">
      <div class="form-group">
        <label for="name">Player's Name</label>
        <input name="name" type="text" class="form-control" id="name" value="<?= isset($name) ? $name : '' ; ?>" required>
      </div>

      <div class="form-group">
        <label for="roll">Player's Roll (Auto-generated)</label>
        <input name="roll" type="text" value="<?= $roll; ?>" class="form-control" id="roll" readonly required>
      </div>

      <div class="form-group">
        <label for="address">Player's Address</label>
        <input name="address" type="text" value="<?= isset($address) ? $address : '' ; ?>" class="form-control" id="address" required>
      </div>

      <div class="form-group">
        <label for="pcontact">Player's Contact #</label>
        <input name="pcontact" type="text" class="form-control" id="pcontact" value="<?= isset($pcontact) ? $pcontact : '' ; ?>" pattern="09[0-9]{9}" placeholder="09XXXXXXXXX" required>
      </div>

      <div class="form-group">
        <label for="sport">Player's Sport</label>
        <select name="sport" class="form-control" id="sport" required>
          <option value="">Select Sport</option>
          <option value="Basketball">Basketball</option>
          <option value="Volleyball">Volleyball</option>
          <option value="Badminton">Badminton</option>
          <option value="Football">Football</option>
          <option value="Athletics">Athletics</option>
        </select>
      </div>

      <div class="form-group">
        <label for="photo">Eligibility Document</label>
        <input name="photo" type="file" class="form-control" id="photo" required>
      </div>

      <div class="form-group text-center">
        <input name="addstudent" value="Add Player" type="submit" class="btn btn-danger">
      </div>
    </form>
  </div>
</div>
