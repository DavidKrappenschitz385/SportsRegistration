<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
  $corepage = end($corepage);
  if ($corepage !== 'index.php') {
    if ($corepage == $corepage) {
      $corepage = explode('.', $corepage);
      header('Location: index.php?page=' . $corepage[0]);
    }
  }

  $id = base64_decode($_GET['id']);
  $oldPhoto = base64_decode($_GET['photo']);

  if (isset($_POST['updatestudent'])) {
    $name = $_POST['name'];
    $roll = $_POST['roll'];
    $address = $_POST['address'];
    $pcontact = $_POST['pcontact'];
    $sport = $_POST['sport'];

    if (!empty($_FILES['photo']['name'])) {
      $photo = $_FILES['photo']['name'];
      $photo_ext = pathinfo($photo, PATHINFO_EXTENSION);
      $photo_new = $roll . date('YmdHis') . '.' . $photo_ext;
    } else {
      $photo_new = $oldPhoto;
    }

    $query = "UPDATE `student_info` SET 
      `name` = '$name',
      `roll` = '$roll',
      `class` = '$sport',
      `city` = '$address',
      `pcontact` = '$pcontact',
      `photo` = '$photo_new'
      WHERE `id` = $id";

    if (mysqli_query($db_con, $query)) {
      if (!empty($_FILES['photo']['name'])) {
        move_uploaded_file($_FILES['photo']['tmp_name'], 'images/' . $photo_new);
        if (file_exists('images/' . $oldPhoto)) {
          unlink('images/' . $oldPhoto);
        }
      }
      header('Location: index.php?page=all-student&edit=success');
    } else {
      header('Location: index.php?page=all-student&edit=error');
    }
  }
?>

<h1 class="text-primary"><i class="fas fa-user-edit"></i> Edit Player Information <small class="text-warning">Update Player</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="index.php?page=all-student">All Players</a></li>
    <li class="breadcrumb-item active">Edit Player</li>
  </ol>
</nav>

<?php
  if (isset($id)) {
    $query = "SELECT `id`, `name`, `roll`, `class`, `city`, `pcontact`, `photo`, `datetime` FROM `student_info` WHERE `id` = $id";
    $result = mysqli_query($db_con, $query);
    $row = mysqli_fetch_array($result);
  }
?>

<div class="row">
  <div class="col-sm-6">
    <form enctype="multipart/form-data" method="POST" action="">
  <div class="form-group">
    <label for="name">Player's Name</label>
    <input name="name" type="text" class="form-control" id="name" value="<?= $row['name']; ?>" required>
  </div>

  <div class="form-group">
    <label for="roll">Player's Roll</label>
    <input name="roll" type="text" class="form-control" id="roll" value="<?= $row['roll']; ?>" required readonly>
  </div>

  <div class="form-group">
    <label for="address">Player's Address</label>
    <input name="address" type="text" class="form-control" id="address" value="<?= $row['city']; ?>" required>
  </div>

  <div class="form-group">
    <label for="pcontact">Player's Contact #</label>
    <input name="pcontact" type="text" class="form-control" id="pcontact" value="<?= $row['pcontact']; ?>" pattern="09[0-9]{9}" required>
  </div>

  <div class="form-group">
    <label for="sport">Player's Sport</label>
    <select name="sport" class="form-control" id="sport" required>
      <option value="<?= $row['class']; ?>" selected><?= $row['class']; ?></option>
      <?php
        $sports = ['Basketball', 'Volleyball', 'Badminton', 'Football', 'Athletics'];
        foreach ($sports as $sport) {
          if ($sport !== $row['class']) {
            echo "<option value='$sport'>$sport</option>";
          }
        }
      ?>
    </select>
  </div>

  <?php if (!empty($row['photo'])): ?>
    <div class="form-group">
      <label>Current Eligibility Document:</label><br>
      <img src="images/<?= $row['photo']; ?>" alt="Eligibility Document" style="max-width: 200px; border: 1px solid #ddd; padding: 5px;">
    </div>
  <?php endif; ?>

  <div class="form-group">
    <label for="photo">Update Eligibility Document (Optional)</label>
    <input name="photo" type="file" class="form-control" id="photo">
  </div>

  <div class="form-group text-center">
    <input name="updatestudent" value="Update Player" type="submit" class="btn btn-danger">
  </div>
</form>

  </div>
</div>
